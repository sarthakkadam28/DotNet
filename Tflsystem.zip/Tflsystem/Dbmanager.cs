using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime;
using System.Text.Json;
using System.Runtime;
using Assesment.Entities;

namespace Persistance
{

    public class DbManger
    {
       
        
    }

}


    